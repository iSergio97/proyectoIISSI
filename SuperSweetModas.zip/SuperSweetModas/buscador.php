<DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/logout.css" />
    <title></title>
  </head>
  <body>
  	
    <main>
    <div id="registro_usuario">
			<a href="registro_usuario.php"> <button type="button"> Registrarse</button></a>
    </div>
    <div id = "login">
    	
    Si estás registrad@ pulse <a href="login.php">aquí </a>
    

		<div id="barra">
			<p><a href="consulta_tiendas.php">Tiendas</a>	Buscador: <input type="text"> <button type="submit">Buscar </button>

			</p>
		</div>
		<!-- Barra con: Categorías || Perfil || Buscador -->
  </main>
  </body>
</html>