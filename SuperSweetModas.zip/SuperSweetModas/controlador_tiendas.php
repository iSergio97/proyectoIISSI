<?php	
	 session_start();	
 if (isset($_REQUEST["OID_TIENDA"])) {
		 $libro["OID_TIENDA"] = $_REQUEST["OID_TIENDA"];
		 $libro["NOMBRETIENDA"] = $_REQUEST["NOMBRETIENDA"];
		 $libro["LOCALIZACION"] = $_REQUEST["LOCALIZACION"];
		 $libro["HORARIO"] = $_REQUEST["HORARIO"];
	
		 $_SESSION["tiendas"] = $tiendas;
 			
		 if (isset($_REQUEST["editar"])) Header("Location: consulta_tiendas.php"); 
		 else if (isset($_REQUEST["grabar"])) Header("Location: accion_modificar_tiendas.php");
		 else  if (isset($_REQUEST["borrar"])) Header("Location: accion_borrar_tiendas.php"); 
	 }
	 else 
		 Header("Location: consulta_tiendas.php");
	
?>