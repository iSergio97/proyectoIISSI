<?php

function consultarTodosArticulos($conexion) {
  $consulta = "select nombre, Talla, Precio, TipoArticulo from Articulos";
  return $conexion->query($consulta);
}






















 ?>
