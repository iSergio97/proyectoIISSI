<header class='cabecera'>
	<div id="logotipo">
		<img src="images/Header.png" alt="&#169 Sweet Modas 2018" />
	</div>
	
</header>