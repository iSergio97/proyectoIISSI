<header class='cabecera'>
	<div id="logotipo">
		<ul class="topnav" id="myTopnav">
		<center>
		<img src="images/Logo2.png" width="175" height="175"alt="&#110 Sweet Modas 2018" />
		</center>
		</ul>
	</div>
	
</header>