<div id="footer">
<footer>
	<link  rel="stylesheet" type="text/css" href="css/ListaPie.css"/>
	<div class="lista">
		<center>
<p class="ordenar">
	<p><strong>
				Copyright by Grupo IISSI 2018 &#160; &#160; &#160; &#160; &#160; &#160; &#160; &#160;

				<a href="FAQs.php">FAQs</a> &#160; &#160; &#160; &#160; &#160; &#160; &#160; &#160;

				Sweet Modas &#169 2018
				</strong>
</p>
</center>
	</div>
</footer>
</div>